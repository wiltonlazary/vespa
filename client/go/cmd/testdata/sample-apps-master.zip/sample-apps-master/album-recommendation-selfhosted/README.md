<!-- Copyright 2017 Yahoo Holdings. Licensed under the terms of the Apache 2.0 license. See LICENSE in the project root. -->
# Vespa sample applications - Album Recommendations

A simple Vespa application which can be deployed on one node, which supports
feeding and running simple queries.

Please refer to the
[vespa quick start guide](https://docs.vespa.ai/en/vespa-quick-start.html)
for more information.
