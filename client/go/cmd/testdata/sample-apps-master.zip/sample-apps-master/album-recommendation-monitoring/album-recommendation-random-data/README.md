<!-- Copyright Verizon Media. Licensed under the terms of the Apache 2.0 license. See LICENSE in the project root. -->
# Vespa sample applications - Album Recommendation Random Data Feeder

A simple java.application that feeds data into the Album Recommendations application using the Vespa Http Client. 


Please refer to
[Monitoring with Grafana quick start](https://docs.vespa.ai/en/monitoring-with-grafana-quick-start.html)
for more information.
