<!-- Copyright Verizon Media. Licensed under the terms of the Apache 2.0 license. See LICENSE in the project root. -->
# Vespa sample applications - Album Recommendations

Please refer to the
[vespa quick start guide](https://docs.vespa.ai/en/monitoring-with-grafana-quick-start.html)
for more information.

This is a repo for Grafana / Prometheus configuration for the quick-start.
