<!-- Copyright Yahoo. Licensed under the terms of the Apache 2.0 license. See LICENSE in the project root. -->

![Vespa logo](https://vespa.ai/assets/vespa-logo-color.png)

# Vespa sample applications - album recommendations

This is not a complete sample application,
but rather the files we add to `album-recommendation` to make it deployable in production.
See [Getting to Production](https://cloud.vespa.ai/en/getting-to-production).
