package ai.vespa.cloud.docsearch;

import ai.vespa.hosted.cd.StagingTest;
import org.junit.jupiter.api.Test;

@StagingTest
public class VespaDocStagingTest {

    @Test
    public void testSearchAndFeeding() throws Exception {

    }

}
