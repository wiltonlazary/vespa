<!-- Copyright Yahoo. Licensed under the terms of the Apache 2.0 license. See LICENSE in the project root. -->

![Vespa logo](https://vespa.ai/assets/vespa-logo-color.png)

# Vespa sample applications - document joins

Refer to [getting-started-java](https://cloud.vespa.ai/en/getting-started-java) to try this sample application.
